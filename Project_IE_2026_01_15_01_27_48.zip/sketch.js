// global conditinals
let kinup
let kinupIE
let showOriginal = false
// setting up imageEiditor
function setup() {
  createCanvas(kinup.width, kinup.height);
  kinupIE = ImageEditor.IEWithCopyOfImage(kinup);
  noLoop()
  kinupIE.startEditing();
 // greyscale ImageEditor Code
  let w = kinupIE.getWidth()
  let h = kinupIE.getHeight()
 
  for (let y = 0; y < h; y++){
    for (let x = 0; x < w; x++){
      let r = kinupIE.getRedAt(x, y)
      let g = kinupIE.getGreenAt(x, y)
      let b = kinupIE.getBlueAt(x, y)
      let avg = (r + g + b) / 3
      let greyColor = color(avg, avg, avg)

      if (g > b && g > r) {
        // keep green areas in color
      } else {
        kinupIE.setColorAt(greyColor, x, y)
      }
    }
  }

  kinupIE.stopEditing()
}

function preload() {
  kinup = loadImage("kinup.png")
}
// draw the original picture so I can change from original to greyscale
function draw() {
  background(220);
  if (showOriginal) {
    image(kinup, 0, 0, width, height)
  } else {
    kinupIE.drawAt(0, 0, width, height)
  }
}

function keyPressed() {
  if (key === '1') showOriginal = true
  if (key === '2') showOriginal = false
  redraw()
}
