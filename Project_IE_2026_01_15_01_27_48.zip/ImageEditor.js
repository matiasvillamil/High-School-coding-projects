//ImageEditor for p5.js
// version 1.1.1
// October 22, 2020
// author Harlan Howe
// based on ImageEditor for Processing version 1.3 September 19, 2016 author: Harlan Howe

/**
 Summary of methods in ImageEditor
 =>There are five ways you can create a new ImageEditor: you can give it ...
 • an existing Image,
 • an existing ImageEditor (not in "Editing Mode"), of which you want a copy,
 • a width & height (which will create an opaque, blank image),
 • a width & height & color (which will create an blank image with the color), or
 • an (x, y, w, h) rectangle, which will copy the contents of the current window into a new ImageEditor.

 For example, you might say:
 var img = loadImage("data/picture.jpg"); // in preload() method.
 var editor = ImageEditor.IEWithCopyOfImage(img); // in setup(), draw() or a method called by them
 or
 var editor = new ImageEditor(600,600,color(128,0,255));

 =>You can ask an ImageEditor for its width() or for its height()

 =>You can ask the ImageEditor to resize the main canvas to the size of this picture, or a multiple of the size of the picture:
 For example, if the image is (320 x 240) you might say
 editor.resizeCanvasToImage();  // this would make the canvas be (320 x 240)
 or
 editor.resizeCanvasToImage(3,2); // this would make the canvas be (960 x 480)

 =>You can have the ImageEditor draw its image onto the main window with its upper-left corner at a specific coordinate:
 editor.drawAt(0,0);
 This only works when you are NOT in "Editing Mode."

 =>You can set the ImageEditor into "Editing Mode" - this is the mode in which you can read and write pixel data, but you cannot
 draw while you are in this mode.
 editor.startEditing();
 editor.stopEditing();
 (I suggest you indent your code between start and stop.)
 You can also ask whether it is in "Editing Mode."
 if (editor.isEditing())
 println("In editing mode.");

 =>In "Editing Mode," you can ask for color information for a given pixel:
 •editor.getRedAt(x,y); // returns a number 0-255
 •editor.getGreenAt(x,y); // returns a number 0-255
 •editor.getBlueAt(x,y); // returns a number 0-255
 •editor.getAlphaAt(x,y); // returns a number 0-255
 •editor.getColorAt(x,y); // returns a huge "color" number (0 - 4,294,967,295) that represents the full RGB value.
 // this large color number is the sort of thing you get when you say "new color(255,128,0)"
 (also can say redAt(x,y), greenAt(x,y), blueAt(x,y), alphaAt(x,y), colorAt(x,y)...)

 =>In "Editing Mode," you can change the color information for a given pixel:
 •editor.setRedAt(r,x,y);
 •editor.setGreenAt(g,x,y);
 •editor.setBlueAt(b,x,y);
 •editor.setAlphaAt(a,x,y);
 •editor.setColorAt(c,x,y);

 =>In any mode, you can ask whether a given set of coordinates fits within the size of this Image:
 •if (editor.inBounds(x,y))
 println("Yep, it's in bounds.");

 =>If you are not in "Editing Mode," you can ask for the Image in this ImageEditor.
 •var imageCopy = editor.getImage();

 =>If you are not in "Editing Mode," you can ask for this ImageEditor to save its Image
 as a file. The filename you give it determines the graphics format. I think you could use .jpg, .gif, .tif, or .png.
 •editor.save("myCoolerFile.png");

 =>If you are not in "Editing Mode," you can ask the this ImageEditor to give you a new
 ImageEditor that consists of a portion of the image in this Image editor, based on
 (x, y, w, h) - relative to this ImageEditor's internal coordinates. If you choose
 values for the image that are out of bounds for the picture, you will get black for
 the extra areas; or if you add a "true" to the end of the parameters, you get
 transparent at the out-of-bounds areas.
 • ImageEditor smallIE = editor.subArea(100,-100,500,30);
 //there will be a black bar across the top of this image (at least), since that part
 //is clearly be out of bounds
 or
 • ImageEditor tinyIE = editor.subArea(-50,0,editor.width(),editor.height(),true);
 //There will be a 50px wide transparent area on the left edge of the image, at least.
 //    The image will be the same size as the original, but the right edge will be cropped.
 */



let ALPHA_BIT_SHIFT = 24;
let RED_BIT_SHIFT = 16;
let GREEN_BIT_SHIFT = 8;
let BLUE_BIT_SHIFT = 0;
let ALL_ONES = 0xFFFFFFFF;

//-------------------------------------------------------------- Class starts here!
class ImageEditor
{
  //int myWidth, myHeight, myNumPixels;
  //PImage myImage;
  //color[] myPixels;
  //boolean isEditing;

  /**
   * creates an ImageEditor of specified (width,height) that starts off filled with color c - using ARGB format.
   * @param width - the width of the blank image created.
   * @param height - the height of the blank image created.
   * @param color - which color goes in each pixel (but alpha will be full opaque.)
   */
  constructor(inWidth, inHeight, c)
  {
    if (inWidth == null || inHeight == null)
    {
        this.myWidth = 50;
        this.myHeight = 50;
    }
    else
    {
        this.myWidth = int(inWidth);
        this.myHeight = int(inHeight);
    }
    this.myImage = createImage(this.myWidth, this.myHeight);
    this.isEditing = false;
    if (c != null)
    {
       this.startEditing();
         for (let i=0; i<this.myWidth; i++)
         {
           for (let j=0; j<this.myHeight; j++)
           {
             this.setColorAt(c,i,j);
           }
         }
       
       this.stopEditing();
    }
    
  }

  static IEOfSize(w,h)
  {
     return new ImageEditor(w,h); 
  }

  static IEOfSizeAndColor(w, h, c)
  {
     return new ImageEditor(w,h,c); 
  }

  /*
  * creates an ImageEditor of specified (w, h) that is filled with content from the screen,
   * using the rectangular section (startX, startY, w, h) as the source of that content.
   * Note: the rectangular section must fall within the confines of the screen.
   */
  static IEWithScreenRect(startX,  startY,  w,  h)
  {
    //pixelDensity(1);
    if (startX+w>width || startY+h>height)
    {
      throw "Attempted to create image with rectangular data from ("+ startX+", "+startY+
      ") to ("+(startX+w)+", "+(startY+h)+"), but the screen is only "+width+" x "+height+
      " pixels.";
    }
    var result = new ImageEditor(w,h);
    var d = pixelDensity();
    loadPixels();
    
    print(width,height,pixels.length);
    result.startEditing();
    print(result.myWidth);
    for ( var y = 0; y<h; y++)
    {
      for ( var x = 0; x< w; x++)
     {
       for (var i=0; i<4; i++)
       {
           result.myPixels[4*((y*w)+x)+i] = pixels[4*d*((y+startY)*d*width + (x+startX)) +i];   
       }
     }
    }
    result.stopEditing();
    updatePixels();
    return result;
  }

  /**
   * creates an ImageEditor with a <i>copy</i> of the specified image, starting off out of editing mode.
   * @param inImage - the image to copy and use.
   */
  static IEWithCopyOfImage(inImage)
  {
    if (inImage == null)
    {
      throw "Attempted to create an ImageEditor with a null image.";
    }
    var result = new ImageEditor(inImage.width,inImage.height);
    result.myImage.copy(inImage, 0, 0, inImage.width, inImage.height, 0, 0, inImage.width, inImage.height);
    result.myWidth = inImage.width;
    result.myHeight = inImage.height;
    //myNumPixels = myWidth * myHeight;
    result.isEditing = false;
    return result;
  }
  /**
   * creates an ImageEditor with a <i>copy</i> of the image in the given ImageEditor.
   * precondition: The given ImageEditor must <i>not</i> be in "Editing Mode."
   * @param IE2Copy - the ImageEditor to copy and use.
   */
  static duplicate( IE2Copy)
  {
    return ImageEditor.IEWithCopyOfImage(IE2Copy.getImage());
  }

  static IEWithCopyOfIE( IE2Copy)
  {
    return duplicate(IE2Copy);
  }

  width()
  {
    return this.myWidth;
  }
  
  getWidth() { return this.width();}

  height()
  {
    return this.myHeight;
  }

  getHeight() { return this.height();}

  isEditing()
  {
    return this.isEditing;
  }


  /**
   * enter "editing mode" - you can now read and manipulate pixel data, but you
   * cannot draw the image until you exit this mode.
   */
  startEditing()
  {
    if (!this.isEditing)
    {
      this.myImage.loadPixels();
      this.myPixels = this.myImage.pixels;
      this.isEditing = true;
    }
  }


  /**
   * exit "editing mode" - you can no longer read or manipulate pixel data,
   * but you can now draw the image.
   */
  stopEditing()
  {
    if (this.isEditing)
    {
      this.myImage.updatePixels();
      this.isEditing = false;

    }
  }


  /**
   * indicates whether the given point is within this image.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  inBounds(x, y)
  {
    return (x>=0) && (x<this.myWidth) && (y>=0) && (y<this.myHeight);
  }

  /**
   * returns the pixel color value at the given coordinates.
   * Note: editing mode must be on to use this method.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   * @return the color of the pixel at (x,y)
   */
  getColorAt(x, y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    let index = 4*(x+this.myWidth*y);
    
    return  color(this.myPixels[index+0],this.myPixels[index+1],this.myPixels[index+2],this.myPixels[index+3]);
  }

  colorAt( x,  y) {
    return this.getColorAt(x, y);
  }
  /**
   * returns the red value  (0-255) at the given coordinates.
   * Note: editing mode must be on to use this method.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   * @return the red of the pixel at (x,y)
   */
  getRedAt( x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    return this.myPixels[4*(x + this.myWidth*y) + 0];
  }
  redAt( x,  y) {
    return this.getRedAt(x, y);
  }

  /**
   * returns the green value  (0-255) at the given coordinates.
   * Note: editing mode must be on to use this method.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   * @return the green of the pixel at (x,y)
   */
  getGreenAt( x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    return this.myPixels[4*(x + this.myWidth*y) + 1];
  }
  greenAt( x,  y) {
    return this.getGreenAt(x, y);
  }

  /**
   * returns the blue value  (0-255) at the given coordinates.
   * Note: editing mode must be on to use this method.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   * @return the blue of the pixel at (x,y)
   */
  getBlueAt( x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    return this.myPixels[4*(x + this.myWidth*y) + 2];
  }
  blueAt( x,  y) {
    return this.getBlueAt(x, y);
  }


  /**
   * returns the alpha value  (0-255) at the given coordinates.
   * Note: editing mode must be on to use this method.
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   * @return the alpha of the pixel at (x,y)
   */
  getAlphaAt( x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to get pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    return this.myPixels[4*(x + this.myWidth*y) + 3];
  }
  alphaAt( x,  y) {
    return this.getAlphaAt(x, y);
  }



  /**
   * updates the red portion of the color at the given (x,y) coordinates.
   * note: editing mode must be on to use this method.
   * @param c - the redness (0-255) to which the pixel should be set
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  setRedAt( val,  x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    this.myPixels[4*(x + this.myWidth*y) + 0] = val;
  }

  /**
   * updates the green portion of the color at the given (x,y) coordinates.
   * note: editing mode must be on to use this method.
   * @param c - the greenness (0-255) to which the pixel should be set
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  setGreenAt( val,  x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    this.myPixels[4*(x + this.myWidth*y) + 1] = val;
  }
  
  /**
   * updates the blue portion of the color at the given (x,y) coordinates.
   * note: editing mode must be on to use this method.
   * @param c - the blueness (0-255) to which the pixel should be set
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  setBlueAt( val,  x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    this.myPixels[4*(x + this.myWidth*y) + 2] = val;
  
  }

  /**
   * updates the alpha portion of the color at the given (x,y) coordinates.
   * note: editing mode must be on to use this method.
   * @param c - the alpha (0-255) to which the pixel should be set
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  setAlphaAt( val,  x,  y)
  {
    if (!this.isEditing)
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to change pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    this.myPixels[4*(x + this.myWidth*y) + 3] = val;
  }

  /**
   * updates the color at the given (x,y) coordinates.
   * note: editing mode must be on to use this method.
   * @param c - the color to which the pixel should be set
   * @param x - the x-coordinate of the pixel
   * @param y - the y-coordinate of the pixel
   */
  setColorAt( c, x, y)
  {
    
    var col = c.levels;
    
    if (!this.isEditing)
    {
      throw "Attempted to set pixel data at ("+x+", "+y+") but image is not in editing mode.";
    }
    if (!this.inBounds(x, y))
    {
      throw "Attempted to set pixel data at ("+x+", "+y+") but this must fall between (0,0) and ("+(this.myWidth-1)+", "+(this.myHeight-1)+"), inclusive.";
    }
    var index = 4*(x+this.myWidth*y);
    for (let i = 0; i<4; i++)
    {
      this.myPixels [index+i] = col[i];
    }
  }

  /**
   * draws the image at the given (x,y) location.
   * Note: this throws an exception (i.e., crashes) if we are in editing mode.
   * @param x - the x-coordinate in the current Matrix where the upper-left image of the image will start.
   * @param y - the y-coordinate in the current Matrix where the upper-left image of the image will start.
   */
  drawAt( x,  y)
  {
    if (this.isEditing)
    {
      throw "Attempted to draw image while in \"Editing Mode.\"";
    }
    image(this.myImage, x, y);
  }
  
  /**
  * draws the image with its center at the given (x,y) location.
  * Note: this throws an exception (i.e., crashes) if we are in editing mode.
  * @param x - the x-coordinate in the current Matrix where the center of the image will start.
  * @param y - the y-coordinate in the current Matrix where the center of the image will start.
  */
  drawCenteredAt(x,y)
  {
     this.drawAt(x-this.myWidth/2, y-this.myHeight/2); 
  }

  save( filename)
  {
    this.myImage.save(filename);
  }

  /**
   * returns a copy of the PImage used in this ImageEditor; further edits to this ImageEditor will
   * not affect the copy returned.
   * @return a copy of the PImage currently used in this ImageEditor.
   */
  getImage()
  {
    if (this.isEditing)
    {
      throw "Attempted to grab image from Image Editor while in \"Editing Mode.\"";
    }
    let tempImage = createImage(this.myWidth,this.myHeight);
    tempImage.copy(this.myImage, 0, 0, this.myWidth, this.myHeight, 0, 0, this.myWidth, this.myHeight);
    return tempImage;
  }

  /**
   * changes the size of the canvas to a multiple of the width and height of this ImageEditor's Image.
   * @param mx - the integer multiplier for x
   * @param my - the integer multiplier for y
   * precondition: mx and my are both >= 1.
   */
  resizeCanvasToImage( mx,  my)
  {
     var multX, multY;
     if (mx == null || my == null)
     {
       multX = 1;
       multY = 1;
     }
     else
     {
       multX = mx;
       multY = my;
     }
    resizeCanvas(this.myWidth*max(1, multX), this.myHeight*max(1, multY));
  }



  subArea( x,  y,  w,  h,  transparentBorder)
  {
    var border;
    if (this.isEditing)
    {
      throw "Attempted to grab subArea from Image Editor while in \"Editing Mode.\"";
    }
    if (transparentBorder == null)
    {
      border = false;
    }
    else
    {
      border = transparentBorder;
    }
    var xMax = min(this.myWidth, x+w);
    var yMax = min(this.myHeight, y+h);
    var xMin = max(0, x);
    var yMin = max(0, y);
    //print (xMax, yMax, xMin, yMin);
    var result = new ImageEditor(w, h, color(0, 0, 0, 255));
    this.startEditing();
    result.startEditing();
    if (border)
    {
      for ( let y3 = 0; y3 < h; y3++)
      {
        for ( let x3 = 0; x3<w; x3++)
        {
          result.setAlphaAt(0, x3, y3);
        }
      }
    }
    for ( let yy = yMin; yy < yMax; yy++)
    {
      for ( let xx = xMin; xx < xMax; xx++)
      {
         let destX = xx-x;
         let destY = yy-y;
        //println ("            ",destX,destY);
        result.setColorAt(this.colorAt(xx, yy), destX, destY);
      }
    }

    result.stopEditing();
    this.stopEditing();
    return result;
  }
}
