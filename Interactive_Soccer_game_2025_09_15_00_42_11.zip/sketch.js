//  Soccer game with a soccer ball and a goalie
// move ball with WASD

let ballX, ballY, ballR;
let speed = 15; // FPS

let goalX,goalY,goalW, goalH; 

let goalieX,goalieY,goalieW,goalieH;

let showGoal= false;
let showSave = false; // shows that it nothing as been saved yet
function setup() {
  createCanvas(600, 500);

  // where the ball spawns
ballR = 18
ballX = width * 0.25;
ballY = height / 2;
    
  // Dimensions of Goal fr
goalW =30;
goalH =180;
goalX =width - goalW;
goalY =(height - goalH) / 2;
}

function draw() {
  // field with clean cut grass
background(30, 160, 60);
stroke(255);
strokeWeight(7);
line(width/2,0,width/2,height);   // center line
noFill();
circle(width/2,height/2, 120);       // center circle
noFill();
rect(width-180,height/2-120,150,240); //pen box

  // Goal dimensions
noStroke();
fill(220);
rect(goalX,goalY,goalW,goalH);
noFill();
stroke(255);
strokeWeight(4);
rect(goalX,goalY,goalW,goalH);
// Goalie to block and make game harder
noStroke();
let goalieY = mouseY;
fill("black");
rect(480,goalieY,10,100);
  // Ball moved with WASD
   {
if (keyIsDown(65)) ballX -= speed; // A key
if (keyIsDown(68)) ballX += speed; // D key
if (keyIsDown(87)) ballY -= speed; // W
if (keyIsDown(83)) ballY += speed; // S
  
}

// draw ball
noStroke();
fill(255);
circle(ballX, ballY, ballR * 2.3);
  
  // chat gpt didnt know how to check goalie collision
  if (ballX + ballR > 480 && ballX - ballR < 480+10 && // check if the x values touch the goalies
      ballY + ballR > goalieY && ballY - ballR < goalieY+100) { // check if it touches the y values of the goalie
    showSave = true;// shows that it saves it
    ballX = 460; // push ball back a little so it stops in front of it
  }

  // Chat Gpt Only says goal if inside the net
 if (
  !showGoal &&               // 1 shows the text whne it goes in goal
  ballX + ballR >= goalX &&//2 makes sure ball passes goals x value
  ballY > goalY &&           // 3 makes sure ball passes the y value
  ballY < goalY + goalH      // 4 makes sure it only says goal if it goes in the goal not just around it
) {
  showGoal = true; // 5 shows the goal text
}
// GPT ended here

  // show message if goal
if (showGoal) {
fill(255);
textAlign(CENTER, CENTER);
textSize(28);
text("What a goal lad!", width / 2, 50);
  }

}
