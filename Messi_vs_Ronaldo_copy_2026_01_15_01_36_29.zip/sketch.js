

let players = [];
let stat = "goals"; 

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER);
  textSize(20);

  let messi = {
    name: "Messi",
    goals: 834,
    assists: 361,
    trophies: 44,
    ballonDors: 8
  };

  let ronaldo = {
    name: "Ronaldo",
    goals: 873,
    assists: 247,
    trophies: 35,
    ballonDors: 5
  };

  players = [messi, ronaldo];
}

function draw() {
  background(230);
  
  textSize(28);
  fill(0);
  text("Messi vs Ronaldo", width / 2, 50);

  
  textSize(20);
  text("Comparing:" + stat, width / 2, 84);
//chat gpt starts here. it compares the values that are given and makes the square that has the values
  let messiValue = players[0][stat];
  let ronaldoValue = players[1][stat];

  
  drawScoreBox(width / 2 - 150, 150, players[0].name, messiValue);
  drawScoreBox(width / 2 + 150, 150, players[1].name, ronaldoValue);

 // compares the value and decides on a winner that is shown in the bottem
  let winner = messiValue > ronaldoValue ? "Messi" : "Ronaldo";
  fill(0);
  textSize(24);
  text("Winner: " + winner, width / 2, 320);
//chat gpt ends here
  
  textSize(14);
  text("Press 1 goals   2 assists   3 trophies   4 Ballon D'ors", width / 2, 360);
}

function drawScoreBox(x, y, playerName, value) {
  rectMode(CENTER);
  fill(255);
  rect(x, y, 200, 120, 10);

  fill(0);
  textSize(20);
  text(playerName, x, y - 20);

  textSize(26);
  text(value, x, y + 20);
}

// Change the stat when keys are pressed
function keyPressed() {
  if (key === '1') stat = "goals";
  if (key === '2') stat = "assists";
  if (key === '3') stat = "trophies";
  if (key === '4') stat = "ballonDors";
}
